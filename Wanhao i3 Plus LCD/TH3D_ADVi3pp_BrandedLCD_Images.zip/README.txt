These are custom images for the Wanhao i3 Plus when using the ADVi3++ firmware on the LCD.

How to use:

1. Write the LCD Firmare image to a MicroSD card
2. Unplug and replug the MicroSD card
3. Copy the DWIN_SET folder from this Zip file to the MicroSD card root and over-write all the files already on the MicroSD card
4. With the power off insert the MicroSD card and power the machine on. The images will cycle through and update to the new ones.